﻿using Pavabits.Framework.Application.Services;
using $rootnamespace$.Services.#folder#.Dtos;

namespace $rootnamespace$.Services.#folder#
{
    public interface $safeitemname$ : IApplicationService<Guid, $fileinputname$CreationDto, $fileinputname$UpdateDto, $fileinputname$ReadingDto>
    {
    }
}