﻿using ZFramework.Application.Services.Dtos;

namespace $rootnamespace$.Services.#folder#.Dtos
{
    public class $safeitemname$ : EntityDto
    {
    }
}