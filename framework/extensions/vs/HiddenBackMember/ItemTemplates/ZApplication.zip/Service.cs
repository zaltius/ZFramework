﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using Pavabits.Framework.Application.Services;
using Pavabits.Framework.Domain.UnitOfWork;
using $rootnamespace$.Services.#folder#.Dtos;
using #projectname#.Domain.Entities.#folder#;

namespace $rootnamespace$.Services.#folder#
{
    public class $safeitemname$ : ApplicationService<$fileinputname$, Guid, I$fileinputname$Repository, $fileinputname$CreationDto, $fileinputname$UpdateDto, $fileinputname$ReadingDto>, I$fileinputname$Service
    {
        public $safeitemname$(
            ILogger<$safeitemname$> logger,
            IMapper mapper,
            IUnitOfWork unitOfWork,
            I$fileinputname$Repository repository)
            : base(logger, mapper, unitOfWork, repository)
        {
        }
    }
}