﻿using AutoMapper;
using #projectname#.Domain.Entities.#folder#;

namespace $rootnamespace$.Services.#folder#.Dtos
{
    public sealed class $safeitemname$ : Profile
    {
        public $safeitemname$()
        {
            CreateMap<$fileinputname$, $fileinputname$ReadingDto>();

            CreateMap<$fileinputname$CreationDto, $fileinputname$>();

            CreateMap<$fileinputname$UpdateDto, $fileinputname$>();
        }
    }
}