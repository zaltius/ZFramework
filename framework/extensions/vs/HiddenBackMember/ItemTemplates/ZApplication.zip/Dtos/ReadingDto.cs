﻿using Pavabits.Framework.Application.Services.Dtos.Auditing;

namespace $rootnamespace$.Services.#folder#.Dtos
{
    public class $safeitemname$ : AuditedEntityDto<Guid>
    {
    }
}