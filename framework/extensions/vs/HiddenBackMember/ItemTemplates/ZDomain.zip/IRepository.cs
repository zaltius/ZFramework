﻿using ZFramework.Domain.EntityFrameworkCore;

namespace $rootnamespace$.Entities.#folder#
{
    public interface $safeitemname$ : IRepository<$fileinputname$, Guid>
    {
    }
}