using #projectname#.Application.Services.#folder#.Dtos;
using #projectname#.Application.Services.#folder#;
using ZFramework.Web.Controllers;

namespace $rootnamespace$
{
    /// <summary>
    /// Controlado para recibir las peticiones referentes a los #folder#.
    /// </summary>
    public class $safeitemname$ : ApiController<Guid, I$fileinputname$Service, $fileinputname$CreationDto, $fileinputname$UpdateDto, $fileinputname$ReadingDto>
    {
        public $safeitemname$(
            I$fileinputname$Service service,
            ILogger<$safeitemname$> logger)
            : base(service, logger)
        {
        }
    }
}