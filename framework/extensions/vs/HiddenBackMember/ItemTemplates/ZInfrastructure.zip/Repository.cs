﻿using ZFramework.Infrastructure.EntityFrameworkCore.Repositories;
using #projectname#.Domain.Entities.#folder#;

namespace $rootnamespace$.Repositories.#folder#
{
    public class $safeitemname$ : RepositoryBase<$fileinputname$, Guid, ApplicationDbContext>, I$safeitemname$
    {
        public $safeitemname$(ApplicationDbContext dbContext) : base(dbContext)
        {
        }
    }
}